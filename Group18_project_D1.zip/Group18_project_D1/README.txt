## Team Members:
- Chen, Yu-Hsuan (Currently unnable to contact)
- Fatine, Elias (300197450)
- Jaber, Hasan (300303045)
- King, Kalan (300300418)
- Salazar, Rachelle Kim


**Link to the repository:** https://github.com/SEG2105BC-uOttawa/seg2105f23-project-project_group_18